from setuptools import setup

setup(
    name='Darwinex-ticks',
    version='0.0.3',
    packages=[''],
    url='https://github.com/paduel/Darwinex-ticks',
    license='MIT',
    author='Paduel',
    author_email='paduel@gmail.com',
    description='Darwinex tick data downloader Python API',
)
