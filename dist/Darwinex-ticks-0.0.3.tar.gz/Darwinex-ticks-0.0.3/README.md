# Darwinex-ticks
Darwinex tick data python API
